**************************************************************************************
----------------------------#---#--####--#####--#####--####---------------------------
----------------------------#---#--#-------#------#----#------------------------------
-----------------------------#-#---###-----#------#----###----------------------------
-----------------------------#-#---#-------#------#----#------------------------------
------------------------------#----####----#------#----####---------------------------
**************************************************************************************

                      [Bitte erst einmal komplett lesen]


Schauen Sie sich die Datei vetteCompl.wrl in ihrem wrl-Viewer an.
Sofort wird ihnen auffallen, dass die R�der am Modell fehlen.

coordinate.wrl -- Koordinatensysteme wird nur zur besseren Orientierung eingebettet 
                  in das wrl File

vetteChasis.wrl -- enth�lt Chasis, Scheinwerfel, Fenster, ...
vetteWheel.wrl -- enth�lt ein Rad des Autos

vetteCompl.wrl -- Hauptdatei, hier werden alle Teile zusammen gef�gt und animiert


Ordner:
- texture -- enth�lt Texturen
- screenshots -- enth�lt Bilder des Fahrzeuges wie es aussehen soll

---------------------------------------------------------------------------------------


1. �berpr�fen Sie ob der Mittelpunkt der Bounding-Box des Rades im Koordinaten-Ursprung 
      liegt. -- Ist dies nicht der Fall korregieren Sie die Verschiebung !
      (Dies ist notwendig um eine korrekte Rotation zu gew�hrleisten. Versuchen sie es 
        einmal ohne die Korrektur)
2. F�gen Sie die R�der zum Modell hinzu (Bearbeiten Sie hierf�r vetteCompl.wrl)
3. Animieren Sie die R�der so, dass sie sich gleichm�ssig und korrekt drehen