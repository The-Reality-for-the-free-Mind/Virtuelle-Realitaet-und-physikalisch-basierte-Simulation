**************************************************************************************
------#-----#--#####--#---#--#---#--#####--#####--#--#---#--####---#--#--#--####------
------##---##--#---#--#---#--##--#----#----#---#--#--##--#--#---#--#--#-#---#---------
------#-#-#-#--#---#--#---#--#-#-#----#----#####--#--#-#-#--####---#--##----###-------
------#--#--#--#---#--#---#--#--##----#----#---#--#--#--##--#---#--#--#-#---#---------
------#-----#--#####--#####--#---#----#----#---#--#--#---#--####---#--#--#--####------
**************************************************************************************

                      [Bitte erst einmal komplett lesen]


Schauen Sie sich die Datei MtBikeCompl.wrl in ihrem wrl-Viewer an.
Sofort wird ihnen auffallen, dass diverse Teile am Fahrrad wie R�der
und Tretlager fehlen.

coordinate.wrl -- Koordinatensysteme wird nur zur besseren Orientierung eingebettet 
                  in das wrl File

MtBikeFrame.wrl -- enth�lt Rahmen, Sattel, Gabel, ...
MtBikePedal.wrl -- enth�lt Pedale, Zahnrad
MtBikeWheel.wrl -- enth�lt ein Rad des Fahrrades

MtBikeCompl.wrl -- Hauptdatei, hier werden alle Teile zusammen gef�gt und animiert

Ordner:
- screenshots -- enth�lt Bilder des Fahrrades wie es aussehen soll

---------------------------------------------------------------------------------------


1. �berpr�fen Sie ob der Mittelpunkt der Bounding-Box des Rades im Koordinaten-Ursprung 
      liegt. -- Ist dies nicht der Fall korregieren Sie die Verschiebung !
      (Dies ist notwendig um eine korrekte Rotation zu gew�hrleisten. Versuchen sie es 
        einmal ohne die Korrektur)
2. F�gen Sie die R�der und die Pedale zum Fahrrad hinzu (Bearbeiten Sie hierf�r 
      MtBikeCompl.wrl)
3. Animieren Sie die R�der und Pedalen so, dass sie sich gleichm�ssig drehen
4. Animieren Sie die R�der und Pedalen so, dass sich R�der und Pedalen unterschiedlich 
      schnell drehen.